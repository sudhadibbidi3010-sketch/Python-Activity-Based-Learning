# Python-Activity-Based-Learning

## Student Details
- **Name:** D.N.V.JAYASUDHA
- **Roll Number:** 26001137
- **Branch:** Computer Science and Engineering - AIML
- **Section:** CSM-5

## Selected Case Studies
- Case 12: Attendance Recovery Computation (`programs/case12_attendance_recovery.py`)
- Case 13: ATM Transaction Sequence Simulation (`programs/case13_atm_transactions.py`)
- Case 17: Student Performance Trend Analysis (`programs/case17_performance_trend.py`)
- Case 27: Advanced Numeric Pattern Generator (`programs/case27_numeric_pattern.py`)
- Case 29: Password Policy Validation Engine (`programs/case29_password_validation.py`)
- Case 31: String-Based Examination Answer Evaluation (`programs/case31_answer_evaluation.py`)
- Case 35: Text Compression Using Character Runs (`programs/case35_text_compression.py`)
- Case 37: Nested Loop Calendar Generator (`programs/case37_calendar_generator.py`)
- Case 42: Student Marks Matrix Analysis (`programs/case42_marks_matrix.py`)
- Case 53: Food Waste Monitoring System (`programs/case53_food_waste.py`)

## Folder Structure
- `programs/` — 10 Python source files.
- `flowcharts/` — text flowchart outlines for each case study.
- `output_screenshots/` — captured sample program output images and matching text output.
- `Python_ABL_Assignment_Report.pdf` — consolidated report with problem statement, objectives, assumptions, algorithm, flowchart, pseudocode, code, test cases, output and conclusion for each case study.

## How to Run
Install Python 3. Open a terminal in the `programs` folder and run a file, for example:

```bash
python case12_attendance_recovery.py
```

The programs use simple, syllabus-level Python. Sample data is defined near the beginning of each program so that beginners can change values and test other scenarios.

## Important
Review the programs, run them yourself, and be ready to explain each one to your faculty. Confirm whether your faculty requires any handwritten record in addition to the digital submission.
