# Case 31: String-Based Examination Answer Evaluation
answer_key = ["A", "C", "B", "D", "A"]
student_answers = ["A", "B", "B", "", "A"]

if len(answer_key) != len(student_answers):
    print("Error: answer key and response list must have equal lengths.")
else:
    correct = 0
    incorrect = 0
    unanswered = 0

    for i in range(len(answer_key)):
        answer = student_answers[i].strip().upper()
        if answer == "":
            unanswered += 1
        elif answer == answer_key[i]:
            correct += 1
        else:
            incorrect += 1

    score = correct - 0.25 * incorrect
    print("Total questions:", len(answer_key))
    print("Correct answers:", correct)
    print("Incorrect answers:", incorrect)
    print("Unanswered:", unanswered)
    print("Final score: {:.2f} / {}".format(score, len(answer_key)))
