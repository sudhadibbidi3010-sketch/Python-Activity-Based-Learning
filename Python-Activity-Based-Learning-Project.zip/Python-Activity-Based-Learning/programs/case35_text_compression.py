# Case 35: Text Compression Using Character Runs
text = "aaabbccccdaa"

if text == "":
    encoded = ""
else:
    encoded = ""
    current = text[0]
    count = 1

    for ch in text[1:]:
        if ch == current:
            count += 1
        else:
            encoded += current + str(count)
            current = ch
            count = 1
    encoded += current + str(count)

print("Original text:", text)
print("Encoded text:", encoded)
print("Original length:", len(text))
print("Encoded length:", len(encoded))
if len(encoded) < len(text):
    print("Result: encoding is shorter.")
else:
    print("Result: keep the original; encoding is not shorter.")
