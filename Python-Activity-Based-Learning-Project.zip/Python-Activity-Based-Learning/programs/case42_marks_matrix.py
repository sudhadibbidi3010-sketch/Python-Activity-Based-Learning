# Case 42: Student Marks Matrix Analysis
subjects = ["Python", "Maths", "English"]
student_names = ["Anu", "Bala", "Charan"]
marks = [
    [85, 78, 90],
    [72, 88, 80],
    [91, 95, 87]
]

valid = True
for row in marks:
    for mark in row:
        if mark < 0 or mark > 100:
            valid = False

if not valid or any(len(row) != len(subjects) for row in marks):
    print("Invalid marks matrix.")
else:
    print("STUDENT TOTALS AND AVERAGES")
    totals = []
    for i in range(len(marks)):
        total = sum(marks[i])
        average = total / len(subjects)
        totals.append(total)
        print(student_names[i], "Total:", total,
              "Average:", format(average, ".2f"))

    print("\nSUBJECT AVERAGES")
    for j in range(len(subjects)):
        total_for_subject = 0
        for i in range(len(marks)):
            total_for_subject += marks[i][j]
        average = total_for_subject / len(marks)
        print(subjects[j], ":", format(average, ".2f"))

    top_index = totals.index(max(totals))
    print("Top performer:", student_names[top_index], "with", max(totals), "marks")
