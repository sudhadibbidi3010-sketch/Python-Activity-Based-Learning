# Case 13: ATM Transaction Sequence Simulation
# Each tuple contains (transaction_type, amount).
balance = 1000.00
transactions = [
    ("DEPOSIT", 500),
    ("WITHDRAW", 200),
    ("WITHDRAW", 2000),
    ("DEPOSIT", 0),
    ("WITHDRAW", 100)
]
successful = 0
rejected = 0

print("Opening balance: Rs.", format(balance, ".2f"))
for transaction_type, amount in transactions:
    if amount <= 0:
        print(transaction_type, amount, "-> Rejected: amount must be positive")
        rejected += 1
    elif transaction_type == "DEPOSIT":
        balance += amount
        successful += 1
        print("Deposit Rs.", amount, "-> Balance Rs.", format(balance, ".2f"))
    elif transaction_type == "WITHDRAW":
        if amount <= balance:
            balance -= amount
            successful += 1
            print("Withdraw Rs.", amount, "-> Balance Rs.", format(balance, ".2f"))
        else:
            print("Withdraw Rs.", amount, "-> Rejected: insufficient funds")
            rejected += 1
    else:
        print("Unknown transaction -> Rejected")
        rejected += 1

print("Successful transactions:", successful)
print("Rejected transactions:", rejected)
print("Final balance: Rs.", format(balance, ".2f"))
