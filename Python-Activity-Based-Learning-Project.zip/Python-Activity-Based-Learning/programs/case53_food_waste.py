# Case 53: Food Waste Monitoring System
days = ["Monday", "Tuesday", "Wednesday", "Thursday"]
prepared = [200, 180, 220, 150]
served = [185, 170, 190, 145]
limit = 10

if not (len(days) == len(prepared) == len(served)):
    print("Error: daily lists must have equal lengths.")
else:
    total_prepared = 0
    total_leftover = 0
    print("FOOD WASTE REPORT")
    for i in range(len(days)):
        if prepared[i] <= 0 or served[i] < 0 or served[i] > prepared[i]:
            print(days[i], "-> Invalid meal counts")
        else:
            leftover = prepared[i] - served[i]
            rate = leftover / prepared[i] * 100
            total_prepared += prepared[i]
            total_leftover += leftover
            print(days[i], "| Prepared:", prepared[i],
                  "| Served:", served[i], "| Leftover:", leftover,
                  "| Waste: {:.2f}%".format(rate))
            if rate > limit:
                print("  Warning: wastage is above {}%".format(limit))

    if total_prepared > 0:
        overall = total_leftover / total_prepared * 100
        print("Total meals prepared:", total_prepared)
        print("Total leftovers:", total_leftover)
        print("Overall wastage: {:.2f}%".format(overall))
