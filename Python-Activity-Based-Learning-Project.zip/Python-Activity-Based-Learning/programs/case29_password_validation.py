# Case 29: Password Policy Validation Engine
# Educational examples only. Do not use real personal passwords here.
passwords = ["Hello123!", "hello123", "ABC123!!", "GoodDay#7"]

for password in passwords:
    failed = []
    if len(password) < 8:
        failed.append("at least 8 characters")
    if not any(ch.isupper() for ch in password):
        failed.append("an uppercase letter")
    if not any(ch.islower() for ch in password):
        failed.append("a lowercase letter")
    if not any(ch.isdigit() for ch in password):
        failed.append("a digit")
    if not any(not ch.isalnum() for ch in password):
        failed.append("a special character")

    if len(failed) == 0:
        print(password, "-> Valid password format")
    else:
        print(password, "-> Invalid; needs", ", ".join(failed))
