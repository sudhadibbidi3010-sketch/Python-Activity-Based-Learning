# Case 17: Student Performance Trend Analysis
subjects = ["Python", "Mathematics", "Digital Technology", "English"]
assessment_1 = [65, 72, 80, 68]
assessment_2 = [78, 70, 86, 75]

if len(subjects) != len(assessment_1) or len(subjects) != len(assessment_2):
    print("Error: subject and mark lists must have equal lengths.")
elif any(mark < 0 or mark > 100 for mark in assessment_1 + assessment_2):
    print("Error: marks must be between 0 and 100.")
else:
    print("STUDENT PERFORMANCE TREND")
    for i in range(len(subjects)):
        change = assessment_2[i] - assessment_1[i]
        if change > 0:
            trend = "Improved"
        elif change < 0:
            trend = "Declined"
        else:
            trend = "No change"
        print(subjects[i], ":", assessment_1[i], "->", assessment_2[i],
              "| Change:", change, "|", trend)

    average_1 = sum(assessment_1) / len(assessment_1)
    average_2 = sum(assessment_2) / len(assessment_2)
    weakest_index = assessment_2.index(min(assessment_2))
    print("Assessment 1 average: {:.2f}".format(average_1))
    print("Assessment 2 average: {:.2f}".format(average_2))
    print("Subject needing most attention:", subjects[weakest_index])
