# Case 27: Advanced Numeric Pattern Generator
rows = 5

if rows < 1 or rows > 9:
    print("Please choose a row count from 1 to 9.")
else:
    for i in range(1, rows + 1):
        print(" " * (rows - i), end="")
        for j in range(1, i + 1):
            print(j, end="")
        for j in range(i - 1, 0, -1):
            print(j, end="")
        print()
