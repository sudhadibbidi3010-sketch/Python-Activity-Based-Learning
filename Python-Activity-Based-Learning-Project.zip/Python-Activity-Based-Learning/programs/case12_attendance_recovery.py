# Case 12: Attendance Recovery Computation
# Sample values can be changed to test another student.
attended = 42
total_classes = 60
target = 75

if total_classes <= 0 or attended < 0 or attended > total_classes:
    print("Invalid attendance data.")
else:
    current = attended / total_classes * 100
    print("Classes attended:", attended)
    print("Total classes:", total_classes)
    print("Current attendance: {:.2f}%".format(current))
    print("Target attendance: {}%".format(target))

    extra = 0
    while (attended + extra) / (total_classes + extra) * 100 < target:
        extra += 1

    if extra == 0:
        print("You have already reached the target.")
    else:
        print("Consecutive classes to attend:", extra)
        print("Projected attendance: {:.2f}%".format(
            (attended + extra) / (total_classes + extra) * 100
        ))
