# Case 37: Nested Loop Calendar Generator
month_name = "Sample Month"
days = 30
start_day = 2  # Monday=0, Tuesday=1, Wednesday=2, ... Sunday=6

if days < 28 or days > 31 or start_day < 0 or start_day > 6:
    print("Invalid month length or starting weekday.")
else:
    print(month_name)
    print("Mon Tue Wed Thu Fri Sat Sun")
    print("    " * start_day, end="")

    for day in range(1, days + 1):
        print("{:>3} ".format(day), end="")
        if (start_day + day) % 7 == 0:
            print()
    print()
